from django.shortcuts import render
from rest_framework import viewsets
from . models import approvals
from . serializer import approvalsSerializer
from . forms import MyForm
from . import trained
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
import keras
from keras.models import Sequential
from keras import layers
from keras.layers import Dense, Dropout
from sklearn.metrics import confusion_matrix
from tensorflow.keras.models import load_model
import os
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
from django.views.generic import TemplateView
from rest_framework.response import Response
# Create your views here.

class ApprovalsView(viewsets.ModelViewSet):
	queryset=approvals.objects.all()
	serializer_class=approvalsSerializer
		
@method_decorator(login_required, name="dispatch")
class HomeView(TemplateView):
    	template_name = 'myform/home.html'

def getPredictions(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z, ab, bc, cd, de, ef, fg, gh, hi, ij, jk, kl, lm, mn, no, op, pq, qr, rs, st, tu, uv, vw, wx, xy, yz, za, abc, bcd, cde, d_ef, efg, fgh, ghi,hij, ijk, jkl, klm, lmn, mno, nop, opq, pqr, qrs, rst, stu, tuv, uvw, vwx, wxy, xyz, yza, zab, a_a, b_b, c_c, d_d, e_e, f_f, g_g, h_h, i_i, j_j, k_k, l_l, m_m, n_n, o_o, p_p, q_q, r_r, s_s, t_t, u_u, v_v, w_w, x_x, y_y, z_z, a_ab, b_bc, c_cd, d_de, e_ef, f_fg, g_gh, h_hi, i_ij, j_jk, k_kl, l_lm, m_mn, n_no, o_op, p_pq, q_qr, r_rs, s_st, t_tu, u_uv, v_vw, w_wx, x_xy, y_yz, z_za,aa_aa,bb_bb):
    pkl_filename='my_model'
    model=load_model(pkl_filename)
    y_pred = model.predict([[a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z, ab, bc, cd, de, ef, fg, gh, hi, ij, jk, kl, lm, mn, no, op, pq, qr, rs, st, tu, uv, vw, wx, xy, yz, za, abc, bcd, cde, d_ef, efg, fgh, ghi,hij, ijk, jkl, klm, lmn, mno, nop, opq, pqr, qrs, rst, stu, tuv, uvw, vwx, wxy, xyz, yza, zab, a_a, b_b, c_c, d_d, e_e, f_f, g_g, h_h, i_i, j_j, k_k, l_l, m_m, n_n, o_o, p_p, q_q, r_r, s_s, t_t, u_u, v_v, w_w, x_x, y_y, z_z, a_ab, b_bc, c_cd, d_de, e_ef, f_fg, g_gh, h_hi, i_ij, j_jk, k_kl, l_lm, m_mn, n_no, o_op, p_pq, q_qr, r_rs, s_st, t_tu, u_uv, v_vw, w_wx, x_xy, y_yz, z_za,aa_aa,bb_bb]])
    prediction = np.argmax(y_pred, axis=-1) 
    for i in prediction:
    	return i
    
def myform(request):
    return render(request, 'myform/oxform.html')
    
def result(request):
    if request.method == "POST":
        itching = int(request.POST['itching'])
        skin_rash = int(request.POST['skin_rash'])
        nodal_skin_eruptions = int(request.POST['nodal_skin_eruptions'])
        continuous_sneezing = int(request.POST['continuous_sneezing'])
        shivering = int(request.POST['shivering'])
        chills = int(request.POST['chills'])
        joint_pain = int(request.POST['joint_pain'])
        stomach_pain = int(request.POST['stomach_pain'])
        acidity = int(request.POST['acidity'])
        ulcers_on_tongue = int(request.POST['ulcers_on_tongue'])
        muscle_wasting = int(request.POST['muscle_wasting'])
        vomiting = int(request.POST['vomiting'])
        burning_micturition = int(request.POST['burning_micturition'])
        spotting_urination = int(request.POST['spotting_urination'])
        fatigue = int(request.POST['fatigue'])
        weight_gain = int(request.POST['weight_gain'])
        anxiety = int(request.POST['anxiety'])
        cold_hands_and_feets = int(request.POST['cold_hands_and_feets'])
        mood_swings = int(request.POST['mood_swings'])
        weight_loss = int(request.POST['weight_loss'])
        restlessness = int(request.POST['restlessness'])
        lethargy = int(request.POST['lethargy'])
        patches_in_throat = int(request.POST['patches_in_throat'])
        irregular_sugar_level = int(request.POST['irregular_sugar_level'])
        cough = int(request.POST['cough'])
        high_fever = int(request.POST['high_fever'])
        sunken_eyes = int(request.POST['sunken_eyes'])
        breathlessness = int(request.POST['breathlessness'])
        sweating = int(request.POST['sweating'])
        dehydration = int(request.POST['dehydration'])
        indigestion = int(request.POST['indigestion'])
        headache = int(request.POST['headache'])
        yellowish_skin = int(request.POST['yellowish_skin'])
        dark_urine = int(request.POST['dark_urine'])
        nausea = int(request.POST['nausea'])
        loss_of_appetite = int(request.POST['loss_of_appetite'])
        
        pain_behind_the_eyes = int(request.POST['pain_behind_the_eyes'])
        back_pain = int(request.POST['back_pain'])
        constipation = int(request.POST['constipation'])
        abdominal_pain = int(request.POST['abdominal_pain'])

        diarrhoea = int(request.POST['diarrhoea'])
        mild_fever = int(request.POST['mild_fever'])
        yellow_urine = int(request.POST['yellow_urine'])
        yellowing_of_eyes = int(request.POST['yellowing_of_eyes'])

        acute_liver_failure = int(request.POST['acute_liver_failure'])
        fluid_overload = int(request.POST['fluid_overload'])
        swelling_of_stomach = int(request.POST['swelling_of_stomach'])
        swelled_lymph_nodes = int(request.POST['swelled_lymph_nodes'])

        malaise = int(request.POST['malaise'])
        blurred_and_distorted_vision = int(request.POST['blurred_and_distorted_vision'])
        phlegm = int(request.POST['phlegm'])
        throat_irritation = int(request.POST['throat_irritation'])

        redness_of_eyes = int(request.POST['redness_of_eyes'])
        sinus_pressure = int(request.POST['sinus_pressure'])
        runny_nose = int(request.POST['runny_nose'])
        congestion = int(request.POST['congestion'])

        chest_pain = int(request.POST['chest_pain'])
        weakness_in_limbs = int(request.POST['weakness_in_limbs'])
        fast_heart_rate = int(request.POST['fast_heart_rate'])
        pain_during_bowel_movements = int(request.POST['pain_during_bowel_movements'])
        
        pain_in_anal_region = int(request.POST['pain_in_anal_region'])
        bloody_stool = int(request.POST['bloody_stool'])
        irritation_in_anus = int(request.POST['irritation_in_anus'])
        neck_pain = int(request.POST['neck_pain'])

        dizziness = int(request.POST['dizziness'])
        cramps = int(request.POST['cramps'])
        bruising = int(request.POST['bruising'])
        obesity = int(request.POST['obesity'])

        swollen_legs = int(request.POST['swollen_legs'])
        swollen_blood_vessels = int(request.POST['swollen_blood_vessels'])
        puffy_face_and_eyes = int(request.POST['puffy_face_and_eyes'])
        enlarged_thyroid = int(request.POST['enlarged_thyroid'])
        brittle_nails = int(request.POST['brittle_nails'])
        swollen_extremeties = int(request.POST['swollen_extremeties'])
        excessive_hunger = int(request.POST['excessive_hunger'])
        extra_marital_contacts = int(request.POST['extra_marital_contacts'])

        drying_and_tingling_lips = int(request.POST['drying_and_tingling_lips'])
        slurred_speech = int(request.POST['slurred_speech'])
        knee_pain = int(request.POST['knee_pain'])
        hip_joint_pain = int(request.POST['hip_joint_pain'])

        muscle_weakness = int(request.POST['muscle_weakness'])
        stiff_neck = int(request.POST['stiff_neck'])
        swelling_joints = int(request.POST['swelling_joints'])
        movement_stiffness = int(request.POST['movement_stiffness'])
        
        spinning_movements = int(request.POST['spinning_movements'])
        loss_of_balance = int(request.POST['loss_of_balance'])
        unsteadiness = int(request.POST['unsteadiness'])
        weakness_of_one_body_side = int(request.POST['weakness_of_one_body_side'])

        loss_of_smell = int(request.POST['loss_of_smell'])
        bladder_discomfort = int(request.POST['bladder_discomfort'])
        foul_smell_of_urine = int(request.POST['foul_smell_of_urine'])
        continuous_feel_of_urine = int(request.POST['continuous_feel_of_urine'])

        passage_of_gases = int(request.POST['passage_of_gases'])
        internal_itching = int(request.POST['internal_itching'])
        toxic_look_typhos = int(request.POST['toxic_look_typhos'])
        depression = int(request.POST['depression'])
        irritability = int(request.POST['irritability'])
        muscle_pain = int(request.POST['muscle_pain'])
        altered_sensorium = int(request.POST['altered_sensorium'])
        red_spots_over_body = int(request.POST['red_spots_over_body'])
        
        belly_pain = int(request.POST['belly_pain'])
        abnormal_menstruation = int(request.POST['abnormal_menstruation'])
        dischromic_patches = int(request.POST['dischromic_patches'])
        watering_from_eyes = int(request.POST['watering_from_eyes'])

        increased_appetite = int(request.POST['increased_appetite'])
        polyuria = int(request.POST['polyuria'])
        family_history = int(request.POST['family_history'])
        mucoid_sputum = int(request.POST['mucoid_sputum'])
        rusty_sputum = int(request.POST['rusty_sputum'])
        lack_of_concentration = int(request.POST['lack_of_concentration'])
        visual_disturbances = int(request.POST['visual_disturbances'])
        receiving_blood_transfusion = int(request.POST['receiving_blood_transfusion'])
        
        receiving_unsterile_injections = int(request.POST['receiving_unsterile_injections'])
        coma = int(request.POST['coma'])
        stomach_bleeding = int(request.POST['stomach_bleeding'])
        distention_of_abdomen = int(request.POST['distention_of_abdomen'])

        history_of_alcohol_consumption = int(request.POST['history_of_alcohol_consumption'])
        fluid_overload = int(request.POST['fluid_overload'])
        blood_in_sputum = int(request.POST['blood_in_sputum'])
        prominent_veins_on_calf = int(request.POST['prominent_veins_on_calf'])
        palpitations = int(request.POST['palpitations'])
        painful_walking = int(request.POST['painful_walking'])
        pus_filled_pimples = int(request.POST['pus_filled_pimples'])
        blackheads = int(request.POST['blackheads'])
        
        scurring = int(request.POST['scurring'])
        skin_peeling = int(request.POST['skin_peeling'])
        silver_like_dusting = int(request.POST['silver_like_dusting'])
        small_dents_in_nails = int(request.POST['small_dents_in_nails'])

        inflammatory_nails = int(request.POST['inflammatory_nails'])
        blister = int(request.POST['blister'])
        red_sore_around_nose = int(request.POST['red_sore_around_nose'])
        yellow_crust_ooze = int(request.POST['yellow_crust_ooze'])
    result=getPredictions(itching, skin_rash, nodal_skin_eruptions, continuous_sneezing, shivering, chills, joint_pain, stomach_pain, acidity, ulcers_on_tongue, muscle_wasting, vomiting, burning_micturition, spotting_urination, fatigue, weight_gain, anxiety, cold_hands_and_feets, mood_swings, weight_loss, restlessness, lethargy, patches_in_throat, irregular_sugar_level, cough, high_fever, sunken_eyes, breathlessness, sweating, dehydration, indigestion, headache, yellowish_skin,dark_urine, nausea, loss_of_appetite, pain_behind_the_eyes,back_pain, constipation, abdominal_pain, diarrhoea, mild_fever,yellow_urine, yellowing_of_eyes, acute_liver_failure, fluid_overload, swelling_of_stomach, swelled_lymph_nodes,malaise, blurred_and_distorted_vision, phlegm, throat_irritation, redness_of_eyes, sinus_pressure, runny_nose, congestion, chest_pain, weakness_in_limbs, fast_heart_rate, pain_during_bowel_movements, pain_in_anal_region, bloody_stool, irritation_in_anus, neck_pain, dizziness, cramps, bruising, obesity, swollen_legs, swollen_blood_vessels, puffy_face_and_eyes, enlarged_thyroid, brittle_nails, swollen_extremeties, excessive_hunger, extra_marital_contacts,drying_and_tingling_lips, slurred_speech, knee_pain, hip_joint_pain, muscle_weakness, stiff_neck, swelling_joints, movement_stiffness, spinning_movements, loss_of_balance, unsteadiness, weakness_of_one_body_side, loss_of_smell, bladder_discomfort, foul_smell_of_urine, continuous_feel_of_urine, passage_of_gases, internal_itching, toxic_look_typhos, depression, irritability, muscle_pain, altered_sensorium, red_spots_over_body,belly_pain, abnormal_menstruation, dischromic_patches, watering_from_eyes, increased_appetite, polyuria, family_history, mucoid_sputum,rusty_sputum, lack_of_concentration, visual_disturbances, receiving_blood_transfusion, receiving_unsterile_injections, coma, stomach_bleeding, distention_of_abdomen, history_of_alcohol_consumption, fluid_overload,blood_in_sputum, prominent_veins_on_calf,palpitations,painful_walking, pus_filled_pimples, blackheads, scurring, skin_peeling,silver_like_dusting, small_dents_in_nails,  inflammatory_nails, blister,red_sore_around_nose, yellow_crust_ooze)
    return render(request, 'myform/result.html',{'result':result})
