from .models import approvals
from rest_framework import serializers


class approvalsSerializer(serializers.ModelSerializer):
    class Meta:
        model = approvals
        fields = "__all__"
