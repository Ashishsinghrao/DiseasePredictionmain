import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
import keras
from keras.models import Sequential
from keras import layers
from keras.layers import Dense, Dropout
from sklearn.metrics import confusion_matrix
from tensorflow.keras.models import load_model
import os


def prep(y):
    le=LabelEncoder()
    y=le.fit_transform(y)
    return y
    
def train(df):
    x=df.drop('prognosis',axis=1)
    y=df['prognosis']
    
    y=prep(y)
    cls=Sequential()
    cls.add(Dense(128, activation='relu', input_dim=132))
    cls.add(Dropout(0.25))
    cls.add(Dense(64, activation='relu'))
    cls.add(Dropout(0.25))
    cls.add(Dense(64, activation='relu'))
    cls.add(Dropout(0.25))
    cls.add(Dense(41, activation='softmax'))
    cls.compile(optimizer="Adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"])
    cls.fit(x, y, batch_size=200, epochs=150)
    cls.save('my_model')  

#df = pd.read_csv('Disease/Training.csv')
#train(df)
    
    
    
